package com.bridgeit.ipl2017.intrface;

import android.graphics.Bitmap;

/**
 * Created by bridgeit on 30/1/17.
 */

public interface DownloadImageInterface {

    void getImage(Bitmap mBitmap);
}
