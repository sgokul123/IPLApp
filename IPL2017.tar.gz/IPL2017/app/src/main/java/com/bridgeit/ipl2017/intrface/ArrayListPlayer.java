package com.bridgeit.ipl2017.intrface;

import com.bridgeit.ipl2017.model.PlayerInfoModel;

import java.util.ArrayList;

/**
 * Created by bridgeit on 27/1/17.
 */

public interface ArrayListPlayer {
    void fireBaseData(ArrayList<PlayerInfoModel> playerInfoModels);
}
