package com.bridgeit.ipl2017.intrface;

import android.graphics.Bitmap;

import java.util.ArrayList;

/**
 * Created by bridgeit on 1/2/17.
 */

public interface DownloadAllImageInterface {
 void getImage(ArrayList<Bitmap> bitmaps);
}
