package com.bridgeit.ipl2017.intrface;

/**
 * Created by bridgeit on 27/1/17.
 */

public interface LoginInteface {
     void fireBaseLogin(Boolean isLogin);
}
